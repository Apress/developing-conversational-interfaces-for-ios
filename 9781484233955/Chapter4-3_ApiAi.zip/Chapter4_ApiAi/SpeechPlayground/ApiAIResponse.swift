//
//  ApiAIResponse.swift
//  SpeechPlayground
//
//  Created by Martin Mitrevski on 12/03/17.
//  Copyright © 2017 Martin Mitrevski. All rights reserved.
//

import Foundation

public struct ApiAIResponse {
    let addedProducts: [String]
    let removedProducts: [String]
}

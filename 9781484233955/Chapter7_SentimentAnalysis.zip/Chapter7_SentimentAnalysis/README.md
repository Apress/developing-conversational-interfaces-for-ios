# SentimentAnalysis

Source code for the tutorial: https://martinmitrevski.com/2017/07/10/sentiment-analysis-with-core-ml-on-ios-11/.

//
//  ReviewCell.swift
//  SentimentAnalysis
//
//  Created by Martin Mitrevski on 10.07.17.
//  Copyright © 2017 Martin Mitrevski. All rights reserved.
//

import UIKit

class ReviewCell: UITableViewCell {

    @IBOutlet var reviewLabel: UILabel!

}

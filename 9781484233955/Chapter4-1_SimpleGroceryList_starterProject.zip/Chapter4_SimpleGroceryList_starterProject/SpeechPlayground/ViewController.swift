//
//  ViewController.swift
//  SpeechPlayground
//
//  Created by Martin Mitrevski on 02/03/17.
//  Copyright © 2017 Martin Mitrevski. All rights reserved.
//

import UIKit
import Speech

class ViewController: UIViewController, SFSpeechRecognizerDelegate, UITableViewDataSource {
    
    @IBOutlet private var recordingButton: UIButton!
    @IBOutlet private var recognizedText: UITextView!
    @IBOutlet private var productsTableView: UITableView!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private let speechRecognizer: SFSpeechRecognizer! =
        SFSpeechRecognizer(locale: Locale.init(identifier: "en-US"))
    private var products: Set<String> = Set<String>()
    private var addedProducts: [String] = [String]()
    private var sessionProducts: [String] = [String]()
    private var deletedProducts: [String] = [String]()
    private var removalWords: Set<String> = Set<String>()
    private var stoppingWords: Set<String> = Set<String>()
    private var cancelCalled = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func startRecording(sender: UIButton) {
        handleRecordingStateChange()
    }
    
    func handleRecordingStateChange() {

    }
    
    // UITableViewDataSource
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "ProductCell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "ProductCell")
        }
        
        cell?.textLabel?.text = addedProducts[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addedProducts.count
    }
    
}


# TextToSpeech

Source code for the tutorial: https://martinmitrevski.com/2017/03/11/text-to-speech-with-synthesizers.
